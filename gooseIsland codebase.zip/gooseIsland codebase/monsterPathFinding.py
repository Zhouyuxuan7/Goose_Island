from iniscreen import *
from resource1 import *
from cmu_graphics import *
## This file contains the helper function for monster pathfinding. 

##### Breadth First Search Algorithm
### Step 1: Use a 2D list to represent obstacles, start point and end point
# This is a simple example, 'x' represents the obstacles, '0'represents the empty place
# '1' represents the start point (monster position), '2'represents end point (player position)
# [['0', '0', '1'],
# ['0', 'x', '0'],
# ['2', '0', '0']]
### Step 2: create a queue and a currPath
# queue = [''], currPath = ''
# Check if the monster can reach end point in currPath, 
# If no, pop out the first element in the queue, assign the first element value to currPath
# queue = [], currPath = ''
### Step 3
# Create a new variable put
# loop through all four directions, determine the legal move (which is left and down)
# put = currPath + direction, therefore the legal path includes ['L', 'D']
# Add this to the queue, queue = ['L', 'D']
### Step 4 (repeated step 2)
# pop out the first element in the queue: currPath = ['L'], queue = ['D']
# Check if currPath can reaches the end point  --- (No if currPath = ['L'])
### Step 5 (repeated step 3)
# loop through the four directions, put = currPath + direction 
# If put is a legal path, append this to the list
# legal path includes: 'LL', 'LR'
# queue = ['D', 'LL', 'LR']

### Result
# repeated step 2 and step 3, until currPath is the either ['LLD'] or ['DDL']
# the currPath would be one of the shortest paths

def turnToRowCol(s):
    if s=='L': return (0, -1)
    if s=='R': return (0, 1)
    if s=='U': return (-1, 0)
    if s =='D': return (1, 0)

def findIniPoint(mazeL):
    for row in range(len(mazeL)):
        for col in range(len(mazeL[0])):
            if mazeL[row][col] == '1':
                return (row, col)

def findEnd(mazeL, currPath):
    iniRow, iniCol = findIniPoint(mazeL)
    for singleS in currPath:
        drow, dcol = turnToRowCol(singleS)
        iniRow += drow
        iniCol += dcol
    if currPath == '': return False
    if mazeL[iniRow][iniCol] == '2':
        return True
    return False

def valid(mazeL, put):
    row, col = findIniPoint(mazeL)
    for singleS in put:
        drow, dcol = turnToRowCol(singleS)
        row += drow
        col += dcol
        if row < 0 or row >= len(mazeL) or col<0 or col>=len(mazeL[0]) or mazeL[row][col]=='x':
            return False
    return True

def findShortestPath(mazeL):
    queue = ['']
    currPath = ''
    while not findEnd(mazeL, currPath):
        currPath = queue.pop(0)
        if len(currPath) >= 10:
            break
        # print(currPath)
        for move in ['L', 'R', 'U', 'D']:
            put = currPath + move
            if valid(mazeL, put):
                queue.append(put)
    return currPath

# findShortestPath(mazeL)