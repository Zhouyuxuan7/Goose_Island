from cmu_graphics import *
from PIL import Image
import math

# This file draw the game screen's background and the map

def openImage(imagePath, widthRatio = 1, heightRatio = 1):
    image = Image.open(imagePath)
    image = image.resize((math.floor(image.width*widthRatio), math.floor(image.height*heightRatio)))
    return CMUImage(image)

def background(app):
    # Citation: I got the images from https://dontstarve.fandom.com/wiki/Don%27t_Starve_Wiki
    app.forest = openImage('Images/Background/Forest_Turf.webp')
    app.marsh = openImage('Images/Background/Marsh_Turf.webp')
    app.mud = openImage('Images/Background/Mud_Turf.webp')
    app.rocky = openImage('Images/Background/Rocky_Turf.webp')
    app.savanna = openImage('Images/Background/Savanna_Turf.webp')
    app.slimey = openImage('Images/Background/Slimey_Turf.webp')
    # app.back = app.forest
    app.backgroundX = app.width/2
    app.backgroundY = app.height/2
    app.row = 3
    app.col = 4
    app.showOutBoundary = False
    app.map = [[None, None, app.rocky, app.mud, app.savanna, app.savanna, None], 
       [None, app.rocky, app.slimey, app.slimey, app.mud, app.rocky, app.savanna],
       [app.rocky, app.slimey, app.forest, app.forest, app.slimey, app.mud, app.savanna],
       [app.rocky, app.mud, app.marsh, app.forest, app.forest, app.slimey, app.mud], 
       [None, app.rocky, app.slimey, app.marsh, app.slimey, app.marsh, app.savanna],
       [None, None, app.rocky, app.savanna, app.mud, app.savanna, None]]
    app.back = app.map[app.row][app.col]

def drawBackground(app):
    drawImage(app.back, app.backgroundX, app.backgroundY, align = 'center', width = app.width, height = app.height)
    # if app.showOutBoundary:
    #     imageGooseHead = openImage('Images/dec/gooseHead.png', 1/2, 1/2)
    #     drawImage(imageGooseHead, 70, 494, align = 'center')
    #     drawOval(120, app.height - 90, 160, 50, align = 'center', fill = 'bisque', border = 'saddlebrown', borderWidth = 3)
    #     drawLabel("Oh! The Endless Ocean.", 120, app.height-100, bold = True)
    #     drawLabel("I don't wanna go back.", 120, app.height-80, bold = True)

