# Code for goose movement
from cmu_graphics import *
from PIL import Image
from resource1 import *

# This file sets up goose class, and determine its movement

class Goose:
    def __init__(self):
        self.x = app.width/2
        self.y = app.height/2
        self.speed = 20 # maybe 7-9 would be better? 
        self.move = False
        self.healthPoint = 100
        self.hungerPoint = 100
        self.attack = 10
        self.defenceValue = 0

def goose(app):
    app.goose = Goose()
    app.gooseStage = 0
    app.itemDragged = None
    app.itemIsDragged = False
    app.itemDraggedX = None
    app.itemDraggedY = None
    gooseOpen(app)

def gooseNightPos(app):
    if app.night:
        app.goose.x = 3*100 + 25 + 50
        app.goose.y = 2*100 + 25 + 50

# On Step
def gooseWalk(app):
    if app.goose.move == True:
        app.gooseStage += 1
        app.gooseStage = app.gooseStage%5
        gooseOpen(app)
    if app.night == True:
        app.goose.speed = 20

def backGroundSwitch(app):
    switch = False
    # To the right
    if app.goose.x >= app.width:
        app.col += 1
        if app.col <= 6 and app.map[app.row][app.col] != None: 
            app.back = app.map[app.row][app.col]
            app.goose.x = 10
            app.goose.y = app.height/2
            switch = True
        else: 
            app.col -= 1
            app.goose.x -= (app.goose.x-app.width+20)
            app.showOutBoundary = True
    # To the left
    if app.goose.x <= 0:
        app.col -= 1
        if app.col >= 0 and app.map[app.row][app.col] != None: 
            app.back = app.map[app.row][app.col]
            app.goose.x = app.width-10
            app.goose.y = app.height/2
            switch = True
        else: 
            app.col += 1
            app.goose.x += (abs(app.goose.x)+20)
            app.showOutBoundary = True
    # Go up
    if app.goose.y <= 0:
        app.row -= 1
        if app.row >= 0 and app.map[app.row][app.col] != None:
            app.back = app.map[app.row][app.col]
            app.goose.y = app.height-10
            app.goose.x = app.width/2
            switch = True
        else:
            app.row += 1
            app.goose.y += (abs(app.goose.y)+20)
            app.showOutBoundary = True
    # Go down
    if app.goose.y >= app.height: 
        app.row += 1
        if app.row <= 5 and app.map[app.row][app.col] != None:
            app.back = app.map[app.row][app.col]
            app.goose.y = 10
            app.goose.x = app.width/2
            switch = True
        else: 
            app.row -= 1
            app.goose.y -= (app.goose.y-app.height+20)
            app.showOutBoundary = True
    if switch == True:
        configure(app)
        switch = False

def gooseOpen(app):
    # Citation: I got the goose images from https://www.youtube.com/watch?v=9LL2AtHo1gk
    app.gooseOri = Image.open(f'Images/Walking_action1/{app.gooseStage}.png')
    app.gooseFlipped = app.gooseOri.transpose(Image.FLIP_LEFT_RIGHT)
    app.gooseWidth,app.gooseHeight = app.gooseOri.width/5, app.gooseOri.height/5
    app.gooseImage = CMUImage(app.gooseOri)

def gooseMovement(app, keys):
    if 'w' in keys or 's' in keys or 'a' in keys or 'd' in keys:
        app.goose.move = True
    if 'a' in keys and 's' in keys: app.gooseImage = CMUImage(app.gooseFlipped)
    elif 'w' in keys and 'd' in keys: app.gooseImage = CMUImage(app.gooseOri)
    elif 'w' in keys or 'a' in keys: app.gooseImage = CMUImage(app.gooseFlipped)
    elif 's' in keys or 'd' in keys: app.gooseImage = CMUImage(app.gooseOri)
    if app.night == False:
        if 'w' in keys:
            app.goose.y -= app.goose.speed
        if 's' in keys:
            app.goose.y += app.goose.speed
        if 'a' in keys:
            app.goose.x -= app.goose.speed
        if 'd' in keys:
            app.goose.x += app.goose.speed
    elif app.night:
        collideUp = collideDn = collideLf = collideRt = False
        outBoundUp = outBoundDn = outBoundLf = outBoundRt = False
        if 'w' in keys:
            for cX, cY in app.spiderDenLoc:
                if cY <= app.goose.y-35 - app.goose.speed <= cY + 100:
                    if cX <=app.goose.x-25 <= cX + 100 or cX <= app.goose.x+25 <= cX + 100:
                        collideUp = True
                if app.goose.y-35 - app.goose.speed <= 25: outBoundUp = True
            if not collideUp and not outBoundUp: app.goose.y -= app.goose.speed
        if 's' in keys:
            for cX, cY in app.spiderDenLoc:
                if cY <= app.goose.y + 35 + app.goose.speed <= cY + 100:
                    if cX <=app.goose.x-25 <= cX + 100 or cX <= app.goose.x+25 <= cX + 100:
                        collideDn = True
                if app.goose.y + 35 + app.goose.speed >= 525: outBoundDn = True
            if not collideDn and not outBoundDn: app.goose.y += app.goose.speed
        if 'a' in keys:
            for cX, cY in app.spiderDenLoc:
                if cX <= app.goose.x-25 - app.goose.speed <= cX + 100:
                    if cY <= app.goose.y - 35 <= cY + 100 or cY <= app.goose.y+35<= cY + 100:
                        collideLf = True
                if app.goose.x - 25 - app.goose.speed <= 25: outBoundLf = True
            if not collideLf and not outBoundLf: app.goose.x -= app.goose.speed
        if 'd' in keys:
            for cX, cY in app.spiderDenLoc:
                if cX <= app.goose.x+25 + app.goose.speed <= cX + 100:
                    if cY <= app.goose.y-35<= cY + 100 or cY <= app.goose.y+35<= cY + 100:
                        collideRt = True
                if app.goose.x + 25 + app.goose.speed >= 825: outBoundRt = True
            if not collideRt and not outBoundRt: app.goose.x += app.goose.speed
        # print(collideUp, collideDn, collideLf, collideRt)



def gooseStop(app, key):
    app.showOutBoundary = False
    if key == 'w' or key == 's' or key == 'a' or key == 'd' :
        app.goose.move = False
        app.gooseStage = 3
        gooseOpen(app)
    if key == 'a' or key == 'w': app.gooseImage = CMUImage(app.gooseFlipped)
    if key == 'd' or key =='s': app.gooseImage = CMUImage(app.gooseOri)

def drawGoose(app):
    drawImage(app.gooseImage, app.goose.x, app.goose.y, align = 'center', width = 50, height = 70)


