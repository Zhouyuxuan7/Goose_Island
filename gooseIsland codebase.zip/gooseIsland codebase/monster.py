from resource1 import *
from monsterPathFinding import *
from gooseMove import *
import random
import copy
import math
import os, pathlib

## This file creates monsters and obstacles at night

class Monster:
    def __init__(self, name, image, x, y, attack, speedEffect):
        self.name = name
        self.image = image
        self.x = x
        self.y = y
        self.attack = attack
        self.speedEffect = speedEffect
        self.HP = 200
    
    def __repr__(self):
        return f'Monster: {self.name}'
    
    def draw(self):
        if self.name == 'ghost': monster = openImage(self.image, 1/3, 1/3)
        else: monster = openImage(self.image, 1/5, 1/5)
        if self.name == 'ghost':
            if self.y == 0: drawImage(monster, self.x + 20, self.y, width = 40, height = 70)
            else: drawImage(monster, self.x + 20, self.y-30, width = 40, height = 70)
        else:
            if self.y == 0: 
                drawImage(monster, self.x + 20, self.y, width = 70, height = 40)
            else: 
                drawImage(monster, self.x + 20, self.y-30, width = 70, height = 40)

# CITATION: loadSound function code is from CMU 15112 sound demo
def loadSound(relativePath): 
    absolutePath = os.path.abspath(relativePath)
    url = pathlib.Path(absolutePath).as_uri()
    return Sound(url)

# onAppStart
def monsterInd(app):
    # CITATION: 
    # slash sound is from https://pixabay.com/sound-effects/search/attack/
    # monster pictures are from https://dontstarve.fandom.com/wiki/Don%27t_Starve_Wiki
    app.slashSound = loadSound('sound/slash.mp3')
    app.monsterPic = {'spider': 'Images/Monster/Spider.webp', 
                      'spider warrior': 'Images/Monster/Spider_Warrior.webp',
                      'white spider': 'Images/Monster/Dangling_Depth_Dweller.webp', 
                      'ghost': 'Images/Monster/Ghost_Build.webp'}
    # name: health point, speed effect
    app.monsterEffect = {'spider': (-10, 0), 'spider warrior': (-15, 0),
                         'white spider': (-15, -1), 'ghost': (-20, -2)}
    app.monsterAppear = False
    # Goose Initial position
    app.mazeL = [['0']*8 for i in range(5)]
    app.gooseCurCol = int((app.goose.x - 25 )// 100)
    app.gooseCurRow = int((app.goose.y - 25 )// 100)
    app.goosePrevCol = app.gooseCurCol
    app.goosePrevRow = app.gooseCurRow
    app.mazeL[app.gooseCurRow][app.gooseCurCol] = '2'

    # Monsters
    app.currentMonster = []
    iniPos = set() # Hope that different monsters would have different initial X positions
    for monsterNam in app.monsterPic:
        # num = random.randint ()
        # num = 1
        num = random.randint (1, 2)
        for i in range (num):
            attack, speedEffect = app.monsterEffect[monsterNam]
            x = random.randrange(25, app.width-125, 100)
            while x in iniPos:
                x = random.randrange(25, app.width-125, 100)
            oneMonster = Monster(monsterNam, app.monsterPic[monsterNam], x, 0, attack, speedEffect)
            iniPos.add(x)
            app.currentMonster.append(oneMonster)
    # Draw Spider Den, Create 2D list
    app.spiderDen = {'Tier 1': 'Images/Monster/SpiderDenT1.png'}
    app.spiderDenLoc = []
    # for i in range(10):
    for i in range(10):
        x = random.randrange(25, app.width-125, 100)
        y = random.randrange(125, app.height-125, 100)
        row = (y-25)//100
        col = (x-25)//100
        if row == (app.goose.y - 25)//100 and col == (app.goose.x - 25)//100:
            continue
        else:
            app.spiderDenLoc.append((x, y))
            app.mazeL[row][col] = 'x'
    # print(app.mazeL)
    app.monStepCounter = 0

# onStep  
def gooseMoveNight(app):
    if app.night: 
        app.goosePrevRow, app.goosePrevCol = app.gooseCurRow, app.gooseCurCol
        if app.gooseCurCol < 0 or app.gooseCurCol > 7 or app.gooseCurRow < 0 or app.gooseCurRow > 4:
            app.gooseCurCol = 3
            app.gooseCurRow = 2
            app.goosePrevRow, app.goosePrevCol = app.gooseCurRow, app.gooseCurCol
            app.goose.x = app.gooseCurCol*100 + 25 + 50
            app.goose.y = app.gooseCurRow*100 + 25 + 50
        app.gooseCurCol = int((app.goose.x - 25 )// 100)
        app.gooseCurRow = int((app.goose.y - 25 )// 100)
        app.mazeL[app.goosePrevRow][app.goosePrevCol] = '0'
        app.mazeL[app.gooseCurRow][app.gooseCurCol] = '2'
        app.goosePrevRow, app.goosePrevCol = app.gooseCurRow, app.gooseCurCol

def monsterAppear(app):
    if  app.stepCounter >= (app.day*2400+1800):
        app.night = True
        app.monsterAppear = True
    if app.night: app.monStepCounter += 1
    if app.monsterAppear: 
        for oneMonster in app.currentMonster:
            # oneMonster.attack -= app.day * (oneMonster.attack * 0.1)
            if oneMonster.name == 'ghost': continue
            if oneMonster.HP <= 0:
                app.currentMonster.remove(oneMonster)
            row = int(abs((oneMonster.y-25))//100)
            col = int((oneMonster.x-25)//100)
            if (row, col) == (app.gooseCurRow, app.gooseCurCol):
                app.goose.healthPoint += 1/15* oneMonster.attack
                app.goose.speed += 1/20* oneMonster.speedEffect
            else: 
                mazeL = copy.deepcopy(app.mazeL)
                mazeL[row][col] = '1'
                sol = findShortestPath(mazeL)
                if app.monStepCounter % 10 == 0:
                    step = sol[0]
                    mazeL[row][col] = '0'
                    drow, dcol = turnToRowCol(step)
                    oneMonster.x += dcol * 100
                    oneMonster.y += drow * 100

        for oneMonster in app.currentMonster:
            xSign = 1 if app.goose.x > oneMonster.x else -1
            ySign = 1 if app.goose.y > oneMonster.y else -1
            if oneMonster.name == 'ghost':
                dis = distance(app.goose.x, app.goose.y, oneMonster.x, oneMonster.y)
                oneMonster.x += xSign*(abs(app.goose.x-oneMonster.x))*5/dis
                oneMonster.y += ySign*(abs(app.goose.y-oneMonster.y))*5/dis
                if dis <= 20:
                    app.goose.healthPoint += 1/20* oneMonster.attack
                    app.goose.speed += 1/20* oneMonster.speedEffect
            if oneMonster.HP <= 0:
                app.currentMonster.remove(oneMonster)

# Key
def attack(app, key):
    if app.night:
        attackOnce = False
        for oneMonster in app.currentMonster:
            dis = distance(app.goose.x, app.goose.y, oneMonster.x, oneMonster.y)
            if app.equiped and dis <= 70 and key == 'j' and attackOnce == False:
                attackOnce = True
                app.slashSound.play(restart = True)
                if app.equipItem.name == 'axe': oneMonster.HP -= 50
                elif app.equipItem.name == 'pickaxe': oneMonster.HP -= 10

def drawMonster(app):
    if app.night:
        for oneMonster in app.currentMonster:
            oneMonster.draw()
        for tier in app.spiderDen:
            image = openImage(app.spiderDen[tier], 1/5, 1/5)
        for locx, locy in app.spiderDenLoc:
            drawImage(image, locx, locy, width = 100, height = 100)
