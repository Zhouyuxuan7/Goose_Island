from cmu_graphics import *
import math
import random

# This file helps to draw fractal tree

def distance(x1, y1, x2, y2):
    return ((x1-x2)**2 + (y1-y2)**2) **0.5

def onAppStart(app):
    app.width = 400
    app.height = 400
    app.level = 0

def drawFractal(level, sX, sY, eX, eY, dis, angle, width):
    if level == 0:
        drawLine(sX, sY, eX, eY, lineWidth = width)
    else:
       drawLine(sX, sY, eX, eY, lineWidth = width)
       sX = eX
       sY = eY
       dis *= 2/3
       width *= 2/3
       eX1 = sX - dis*math.sin(angle+math.pi/6)
       eY1 = sY - dis*math.cos(angle+math.pi/6)
       eX2 = sX - dis*math.sin(angle-math.pi/9)
       eY2 = sY - dis*math.cos(angle-math.pi/9)
       if dis <= 30:
           radius = random.randint(2, 8)
           colorSet = ['green', 'yellowgreen']
           colorSet = ['plum', 'pink']
           colorInd = random.randint(0, len(colorSet)-1)
           drawCircle(eX1, eY1, radius, fill = colorSet[colorInd])
           drawCircle(eX2, eY2, radius, fill = colorSet[colorInd])
       drawFractal(level-1, sX, sY, eX1, eY1, dis, angle+math.pi/6, width)
       drawFractal(level-1, sX, sY, eX2, eY2, dis, angle-math.pi/9, width)

def onKeyPress(app, key):
    if key in ['up', 'right'] and (app.level <= 7):
        app.level += 1
    elif (key in ['down', 'left']) and (app.level > 0):
        app.level -= 1

def redrawAll(app):
    drawFractal(app.level, 200, app.height - 10, 200, app.height - 110, 100, 0, 10)

runApp(app)