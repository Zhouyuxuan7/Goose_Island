from cmu_graphics import *
from PIL import Image
from collectCrafting import *
import os, pathlib
import random
import math

# This file creates resources on each terrain

# CITATION: I got the images from https://dontstarve.fandom.com/wiki/Don%27t_Starve_Wiki
##### Forest resources ######
forestResourcePic = {'berry bush': ('Images/Forest/Berry_Bush.png', 
                                    'Images/Forest/Berry_Bush_Picked.png'), 
                    'saplings': ('Images/Forest/Sapling.png', 
                                 'Images/Forest/Sapling_picked.png'),
                    'carrots': ('Images/Forest/Carrot.png', 
                                'Images/Forest/Carrot_Hole.webp'),
                    'flint': ('Images/Forest/Flint.webp', 'No picked')}


forestgain = {'berry bush': 'berries', 'saplings': 'twigs', 
              'carrots': 'rawCarrot', 'flint':'flint'}

###### Savanna resources ######
savannaResourcePic = {'grass': ('Images/Savanna/Grass_Tuft.webp', 'Images/Savanna/Picked_Grass_Tuft.webp'),
                      'rock': ('Images/Savanna/Rocks.webp', 'No picked'),
                      'seaweed': ('Images/Food/Seaweed.webp', 'No picked'),
                      'coral': ('Images/Materials/Coral.webp', 'No picked')}

savannagain = {'grass': 'cut grass', 'rock': 'rock', 'seaweed': 'seaweed', 'coral': 'coral'}

###### Mud resources ######
mudResourcePic = {'gold' : ('Images/Mud/Gold_Nugget.webp', 'No picked')}

mudgain = {'gold': 'gold'}

##### Slimey resources #####
slimeyResourcePic = {'green grass': ('Images/Slimey/SW_Grass_Tuft.webp', 'No picked')}

slimeygain = {'green grass': 'grass tuft'}

##### Rocky resources #####
rockyResourcePic = {'gold' : ('Images/Mud/Gold_Nugget.webp', 'No picked'),
                    'ice': ('Images/Materials/Ice.webp', 'No picked'),
                    'rock': ('Images/Savanna/Rocks.webp', 'No picked'),
                    'iron': ('Images/Materials/Iron_Ore.webp', 'No picked')}

rockygain = {'gold':'gold', 'ice': 'ice', 'rock': 'rock', 'iron': 'iron'}

##### Marsh resources ####
marshResourcePic = {}

marshgain = {}


###### Class Attribute & General Funtions ######
class Resource:
    def __init__(self, name, x, y, image, pickedimage, gain):
        self.name = name
        self.x = x
        self.y = y
        self.image = image
        self.pickedimage = pickedimage
        self.gain = gain
        self.collect = False

    def __repr__(self):
        return f'Resource{self.x}, {self.y}'
    
    def __eq__(self, other):
        if not isinstance(other, Resource): 
            return False
        else: 
            return self.name == other.name

    def collected(self):
        self.collect = True
        if self.pickedimage != 'No picked':
            self.image = self.pickedimage
        else: 
            self.image = None
    
    def draw(self):
        if self.image != None:
            # drawImage(self.image, self.x, self.y, align = 'left-bottom')
            drawImage(self.image, self.x, self.y, align = 'left-bottom')

def distance(x1, y1, x2, y2):
    return ((x1-x2)**2 + (y1-y2)**2)**0.5

def openImage(imagePath, widthRatio = 1, heightRatio = 1):
    image = Image.open(imagePath)
    image = image.resize((math.floor(image.width*widthRatio), math.floor(image.height*heightRatio)))
    return CMUImage(image)

# CITATION: loadSound function code is from CMU 15112 sound demo
def loadSound(relativePath): 
    absolutePath = os.path.abspath(relativePath)
    url = pathlib.Path(absolutePath).as_uri()
    return Sound(url)

# Determine which background
# Randomly draw the resources, keep track of their status
# Make a list of their locations, sort them, make sure they draw properly

# Configure Resource
def configure(app):
    # CITATION: pick up sound is from https://pixabay.com/sound-effects/search/pick-up/
    app.collectSound = loadSound('Sound/item-pick-up.mp3')
    app.resourceArrange = []
    app.allLoc = []
    resourcePic = {}
    # Determine resources in different terrains you'll use
    if app.back == app.forest: 
        resourcePic = forestResourcePic
        resourceGain = forestgain
    if app.back == app.savanna:
        resourcePic = savannaResourcePic
        resourceGain = savannagain
    if app.back == app.mud:
        resourcePic = mudResourcePic
        resourceGain = mudgain
    if app.back == app.slimey:
        resourcePic = slimeyResourcePic
        resourceGain = slimeygain
    if app.back == app.rocky:
        resourcePic = rockyResourcePic
        resourceGain = rockygain
    if app.back == app.marsh:
        resourcePic = marshResourcePic
        resourceGain = marshgain
    # Determine the number of each resources in the forest
    for key in resourcePic:
        num = random.randint(2, 6)
        image, pickedImage = resourcePic[key]
        # The trick here is items that disappeared after collecting is often small
        if pickedImage != 'No picked':
            pickedImage = openImage(pickedImage, 1/7, 1/7)
            image = openImage(image, 1/7, 1/7)
        else:
            image = openImage(image, 1/2, 1/2)
        gain = resourceGain[key]
        for i in range(num):
            resX = random.randrange(25, app.width-25, 5)
            resY = random.randrange(25, app.height-25, 5)
            singleResource = Resource(key, resX, resY, image, pickedImage, gain)
            app.resourceArrange.append(singleResource)
            app.allLoc.append((resX, resY))
        # sort app.forestResources, so that if a resource's y value is larger, it draws later
        for i in range(len(app.resourceArrange)-1):
            for j in range(i+1, len(app.resourceArrange)):
                if app.resourceArrange[i].y >= app.resourceArrange[j].y:
                    app.resourceArrange[i], app.resourceArrange[j] = app.resourceArrange[j], app.resourceArrange[i]


# Collect
def forestCollect(app, mouseX, mouseY):
    # Make sure 
    # 1) collect once in one press
    # 2) collect the nearest
    collectedOnce = False
    shortestDis = 50
    shortestRes = None
    for resource in app.resourceArrange:
        if resource.collect == True:
            continue
        if (distance(mouseX, mouseY, resource.x, resource.y) <= shortestDis
        and distance(app.goose.x, app.goose.y, resource.x, resource.y) <= 100
        and resource.collect == False and collectedOnce == False):
            shortestDis = distance(mouseX, mouseY, resource.x, resource.y)
            shortestRes = resource
    # Collect if current item less than 10, or the item presents in current items
    if shortestRes != None: 
        # shortestRes.collected()
        # collectedOnce = True
        # Materials collected
        if shortestRes.gain in app.materialPic:
            material = Material(shortestRes.gain, openImage(app.materialPic[shortestRes.gain]))
        elif shortestRes.gain in app.foodPic:
            material = Food(shortestRes.gain, openImage(app.foodPic[shortestRes.gain]))
        if material not in app.collectedItems and len(app.collectedItems)<10:
            app.collectedItems[material] = 1
            shortestRes.collected()
            app.collectSound.play(restart = True)
            collectedOnce = True
        elif material in app.collectedItems: 
            app.collectedItems[material] += 1
            shortestRes.collected()
            app.collectSound.play(restart = True)
            collectedOnce = True
    print(app.collectedItems)

# Draw
def drawResBeforeGoose(app):
    before = []
    for resource in (app.resourceArrange):
        # 47.5 is the rough distance between center of goose and its bottom foot
        if resource.y <= app.goose.y + 40:
            before.append(resource)
    for resourceBe in before:
        resourceBe.draw()

def drawResAfterGoose(app):
    after = []
    for resource in (app.resourceArrange):
        if resource.y > app.goose.y + 40:
            after.append(resource)
    for resourceAf in after:
        resourceAf.draw()

