from EndingScreen import *
from cmu_graphics import *
from PIL import Image
import math
import random
from collectCrafting import *

# This file draws all the indicators on game screen

def indicators(app):
    app.happyEnding = False
    app.clockHandAngle = 0
    app.stepCounter = 0
    app.day = 0
    app.night = False
    # Clock
    app.clockAngle = math.pi
    app.clockEndX = app.width-75 + 30* math.sin(app.clockAngle)
    app.clockEndY = 50 + 30* math.cos(app.clockAngle)
    # Monster
    app.monsterAppear = False
    app.currentMonster = []
    app.spiderDenLoc = []
    # Happy ending
    app.endingRow = None
    app.endingCol = None
    app.finalHouseDrew = False
    app.noteShown = False
    num = 0
    possiLoc = [(3, 2), (4, 3), (4, 5)]
    app.endingRow, app.endingCol = possiLoc[num]
    # Hint to feed goose
    app.feedHint = False
    app.healthHint = False

# onStep
def clockWalk(app):
    if app.goose.hungerPoint <= 0:
        app.goose.hungerPoint = 0
        app.starve = True
        app.pause = True
    if app.goose.healthPoint <= 0:
        app.goose.healthPoint = 0
        app.starve = True
        app.pause = True
        app.goose.hungerPoint = app.goose.hungerPoint
    if not app.pause:
        app.stepCounter += 1
        app.day = app.stepCounter//2400
        countAngleClock = app.stepCounter//50
        app.clockAngle = math.pi - countAngleClock * math.pi/24
        app.clockEndX = app.width-75 + 30* math.sin(app.clockAngle)
        app.clockEndY = 50 + 30* math.cos(app.clockAngle)
        app.goose.hungerPoint -= (60/2400)
    if  app.stepCounter >= (app.day*2400+1800):
        app.night = True
        app.monsterAppear = True
    if app.day*2400 <= app.stepCounter <= app.day*2400 + 1800:
        app.night = False
        app.monsterAppear = False
    # If night, switch to the dark terrain
    # L = [(2, 3), (3, 4), (5, 4)]
    if app.night:
        app.row, app.col = (3, 2)
        app.back = app.map[3][2]
        app.resourceArrange = []
        if app.goose.x <= 0 or app.goose.x >= app.width or app.goose.y <= 0 or app.goose.y >= app.height:
            app.showOutBoundary = True
        if app.goose.x >= app.width: app.goose.x -= (app.goose.x-app.width+20)
        if app.goose.x <= 0: app.goose.x += (abs(app.goose.x)+20)
        if app.goose.y <= 0: app.goose.y += (abs(app.goose.y)+20)
        if app.goose.y >= app.height: app.goose.y -= (app.goose.y-app.height+20)
    if app.happyEnding == True and app.row == app.endingRow and app.col == app.endingCol:
        app.finalHouseDrew = True
    if app.goose.hungerPoint <= 10:
        app.feedHint = True
    else: app.feedHint = False
    if app.goose.healthPoint <= 10:
        app.healthHint = True
    else: app.healthHint = False

# General Functions
def openImage(imagePath, widthRatio = 1/10, heightRatio = 1/10):
    image = Image.open(imagePath)
    image = image.resize((math.floor(image.width*widthRatio), math.floor(image.height*heightRatio)))
    return CMUImage(image)

# onMousePress for Happy ending
def happyEnding(app, mouseX, mouseY):
    if app.noteShown == True:
        app.noteShown = False 

# redrawAll
# Clock is self-made! 
# CITATION:
# Health icon and hunger icon are from https://dontstarve.fandom.com/wiki/Don%27t_Starve_Wiki
# goose head is from https://steamcommunity.com/sharedfiles/filedetails/?id=1874890319
# smoking goose and knife goose are from https://www.peakpx.com/en/search?q=untitled+goose
# small ducks are from https://tatabanchou.tumblr.com/post/629338963805650944/untitled-royal-family-game
# trash can is from https://stardewvalleywiki.com/Stardew_Valley_Wiki
def drawIndicators(app):
    # clock
    clock = openImage('Images/Indicators/Clock.png')
    drawImage(clock, app.width-75, 50, align = 'center')
    drawLine(app.width-75, 50, app.clockEndX, app.clockEndY, fill = 'red', 
             arrowEnd = True, lineWidth = 2, rotateAngle = app.clockHandAngle)
    drawLabel(f'Day: {app.day}', app.width-75, 50, align = 'center', bold = True)
    # Feeding hint and health hint
    if app.feedHint == True: 
        imageGooseHead = openImage('Images/dec/gooseHead.png', 1/2, 1/2)
        drawImage(imageGooseHead, 70, 494, align = 'center')
        drawOval(120, app.height - 90, 160, 50, align = 'center', fill = 'bisque', border = 'saddlebrown', borderWidth = 3)
        drawLabel("I'm starving...", 120, app.height-100, bold = True)
        drawLabel("Drag the food to feed me!", 120, app.height-85, bold = True)
    elif app.healthHint == True:
        imageGooseHead = openImage('Images/dec/gooseHead.png', 1/2, 1/2)
        drawImage(imageGooseHead, 70, 494, align = 'center')
        drawOval(120, app.height - 90, 160, 50, align = 'center', fill = 'bisque', border = 'saddlebrown', borderWidth = 3)
        drawLabel("I feel weak...", 120, app.height-90, bold = True)
    # hunger bar
    hunger = openImage('Images/Indicators/Hunger_Icon.webp',1/2,1/2)
    drawRect(app.width-50, 100, 80, 15, align = 'center', fill = None, border = 'black')
    length = app.goose.hungerPoint/100*76
    if length >= 1:
        drawRect(762, 94, int(length), 11, fill = 'yellow')
    drawImage(hunger, app.width-100, 100, align = 'center')
    drawLabel(f'{math.ceil(app.goose.hungerPoint)}', app.width-100, 100, align = 'center', bold = True, fill = 'ivory')
    # health bar
    health = openImage('Images/Indicators/Health_Icon.webp',1/2,1/2)
    drawRect(app.width-50, 135, 80, 15, align = 'center', fill = None, border = 'black')
    length = app.goose.healthPoint/100*76
    if length > 0:
        drawRect(762, 130, length, 11,  fill = 'red')
    drawImage(health, app.width-100, 135, align = 'center')
    if app.goose.healthPoint <= 0: 
        drawLabel(f'0', app.width-100, 135, align = 'center', bold = True, fill = 'ivory')
    else:
        drawLabel(f'{math.floor(app.goose.healthPoint)}', app.width-100, 135, align = 'center', bold = True, fill = 'ivory')
    # Trash can
    trashCan = openImage('Images/Indicators/Garbage_Can.png', 1, 1)
    drawImage(trashCan, app.width-50, app.height-50, align = 'center')
    # Instructions on moving and collecting
    if 0 <= app.stepCounter <= 500: 
        imageGooseHead = openImage('Images/dec/gooseHead.png', 1/2, 1/2)
        drawImage(imageGooseHead, 70, 494, align = 'center')
        drawOval(120, app.height - 90, 160, 50, align = 'center', fill = 'bisque', border = 'saddlebrown', borderWidth = 3)
    if 0 <= app.stepCounter <= 100:
        drawLabel("Press 'w''a''s''d' to move", 120, app.height-90, bold = True)
    if 100 <= app.stepCounter <= 200:
        drawLabel("Click on the resources", 120, app.height-100, bold = True)
        drawLabel("to collect", 120, app.height-80, bold = True)
    if 200 <= app.stepCounter <= 300:
        drawLabel("Drag the item in bag", 120, app.height-100, bold = True)
        drawLabel("to feed the goose", 120, app.height-80, bold = True)
    if 300 < app.stepCounter <= 400:
        drawLabel("Remember to check out", 120, app.height-100, bold = True)
        drawLabel("the tool bar!", 120, app.height-80, bold = True)
    if 400 < app.stepCounter <= 500:
        drawLabel("Equip items & press 'j'", 120, app.height-100, bold = True)
        drawLabel("to attack night monsters", 120, app.height-80, bold = True)

    ## Out of boundary
    if app.showOutBoundary:
        imageGooseHead = openImage('Images/dec/gooseHead.png', 1/2, 1/2)
        drawImage(imageGooseHead, 70, 494, align = 'center')
        drawOval(120, app.height - 90, 160, 50, align = 'center', fill = 'bisque', border = 'saddlebrown', borderWidth = 3)
        drawLabel("Oh! The Endless Ocean.", 120, app.height-100, bold = True)
        drawLabel("I don't wanna go back.", 120, app.height-80, bold = True)

    ## Starving (ohno!)
    if app.goose.hungerPoint <= 0: 
        drawRect(app.width/2, app.height/2, 600, 300, align = 'center', fill = 'tan', border = 'darkgoldenrod', borderWidth = 3)
        drawLabel('Ohno! Your goose is starving!', app.width/2, app.height/2 - 95, align = 'center', size = 40, bold = True)
        drawLabel('Take care of him next time', app.width/2, app.height/2 - 30, align = 'center', size = 30, bold = True)
        drawRect(app.width/2 - 100, app.height/2 + 35, 150, 40, align = 'center', fill = 'bisque', border = 'goldenrod', borderWidth = 3)
        drawRect(app.width/2 + 100, app.height/2 + 35, 150, 40, align = 'center', fill = 'bisque', border = 'goldenrod', borderWidth = 3)
        drawLabel('Start again', app.width/2 - 100, app.height/2 + 35, bold = True, size = 20)
        drawLabel('Return to title', app.width/2 + 100, app.height/2 + 35, bold = True, size = 20)
        imageDuck = openImage('Images/dec/small ducks.png', 1, 1)
        drawImage(imageDuck, app.width/2 - 20, app.height/2 + 50, align = 'center')
        imagesmokeGoose = openImage('Images/dec/gooseKill.png', 1/3, 1/3)
        drawImage(imagesmokeGoose, app.width/2 - 230, app.height/2 + 60, align = 'center')
    ## No Health Point 
    if app.goose.healthPoint <= 0:
        drawRect(app.width/2, app.height/2, 600, 300, align = 'center', fill = 'tan', border = 'darkgoldenrod', borderWidth = 3)
        drawLabel('Ohno! Your goose is dying!', app.width/2, app.height/2 - 95, align = 'center', size = 40, bold = True)
        drawLabel('Take care of him next time', app.width/2, app.height/2 - 30, align = 'center', size = 30, bold = True)
        drawRect(app.width/2 - 100, app.height/2 + 35, 150, 40, align = 'center', fill = 'bisque', border = 'goldenrod', borderWidth = 3)
        drawRect(app.width/2 + 100, app.height/2 + 35, 150, 40, align = 'center', fill = 'bisque', border = 'goldenrod', borderWidth = 3)
        drawLabel('Start again', app.width/2 - 100, app.height/2 + 35, bold = True, size = 20)
        drawLabel('Return to title', app.width/2 + 100, app.height/2 + 35, bold = True, size = 20)
        imageDuck = openImage('Images/dec/small ducks.png', 1, 1)
        drawImage(imageDuck, app.width/2 - 20, app.height/2 + 50, align = 'center')
        imagesmokeGoose = openImage('Images/dec/smokingGoose.png', 1/7, 1/7)
        drawImage(imagesmokeGoose, app.width/2 - 230, app.height/2 + 90, align = 'center')

    ## Happy ending!!
    if app.noteShown:
        note = openImage('Images/Happy Ending/Note.jpeg', 1/3, 1/3)
        drawImage(note, app.width/2, app.height/2, align = 'center')
        drawLabel(f'{app.endingRow}, {app.endingCol}', app.width/2, app.height/2 - 30, align = 'center', size = 15)
        drawLabel('The dark place with no resources.', app.width/2, app.height/2 + 30, align = 'center', size = 15)
