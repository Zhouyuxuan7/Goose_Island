from cmu_graphics import *
from PIL import Image
from collectCrafting import openImage
from resource import *
from collectCrafting import *

# This file equip/unequip crafted items

# onAppStart
def equiped(app):
    app.equiped = False
    app.equipItem = None
    app.moveEquipToStore = False
    app.craftedTools = {}
    app.eatingSound = loadSound('Sound/eating-sound.mp3')
    # CITATION: app.eatingSound is from https://pixabay.com/sound-effects/search/chew/

##### Move the equiped item to bag #######
# onMouseMove 
def moveEquipToStore(app, mouseX, mouseY):
    if app.moveEquipToStore and app.equipItem != None:
        app.equipItem.x = mouseX
        app.equipItem.y = mouseY

# onMousePress
# Put pressEquipToStore before puttingCraftedItems
def pressEquipToStore(app, mouseX, mouseY):
    if (650 <= mouseX <= 700 and app.height-50 <= mouseY <= app.height 
              and app.equiped == True):
            app.moveEquipToStore = True
    if 150 <= mouseX <= 650 and app.height-50 <= mouseY <= app.height and app.moveEquipToStore == True:
        app.equiped = False
        app.equipItem.equiped = False
        if app.equipItem not in app.collectedItems and len(app.collectedItems) < 10:
            app.collectedItems[app.equipItem] = 1
        elif app.equipItem in app.collectedItems: 
            app.collectedItems[app.equipItem] += 1
        app.moveEquipToStore = False
        app.equipItem = None

##### Drag the item to...
# (1) feed the goose; (2) throw it to the rubbish bin; (3) Equiped items in bag #####
# onMousePress
def itemIsDragged(app, mouseX, mouseY):
    itemList = []
    for item in app.collectedItems:
        itemList.append(item)
    if 150 <= mouseX <= 650 and app.height-50 <= mouseY <= app.height:
        app.itemIsDragged = True
        ind = (mouseX - 150)//50
        if ind < len(itemList):
            app.itemDragged = itemList[(mouseX - 150)//50]
            app.collectedItems[app.itemDragged] -= 1
            if app.collectedItems[app.itemDragged] == 0:
                app.collectedItems.pop(app.itemDragged)

# onMouseDrag
def moveCurrentItem(app, mouseX, mouseY):
    if app.itemIsDragged: 
        # app.collectedItems.pop(app.itemDragged)
        app.itemDraggedX = mouseX
        app.itemDraggedY = mouseY

# onMouseRelease
def moveCurrentItemToDes(app, mouseX, mouseY):
    if app.itemIsDragged and app.itemDragged != None:
        if 770 <= mouseX <= 830 and 470 <= mouseY <= 530:
            app.itemIsDragged = False
            app.itemDragged = None
            app.itemDraggedX = None
            app.itemDraggedY = None
            app.collectSound.play(restart = True)
        elif 150 <= mouseX <= 650 and app.height-50 <= mouseY <= app.height:
            app.itemIsDragged = False
            if app.itemDragged in app.collectedItems:
                app.collectedItems[app.itemDragged] += 1
            else:
                app.collectedItems[app.itemDragged] = 1
            app.itemDragged = None
            app.itemDraggedX = None
            app.itemDraggedY = None
        elif distance(mouseX, mouseY, app.goose.x, app.goose.y) <= 30:
            if isinstance(app.itemDragged, Food):
                app.eatingSound.play(restart = True)
                value = app.foodValue[app.itemDragged.name]
                app.goose.hungerPoint += value
                if app.goose.hungerPoint >= 100:
                    app.goose.hungerPoint = 100
                app.itemDragged = None
                app.itemDraggedX = None
                app.itemDraggedY = None
        elif (650 <= mouseX <= 700 and app.height-50 <= mouseY <= app.height 
              and app.equiped == False):
            if isinstance(app.itemDragged, CraftItem):
                app.equipItem = app.itemDragged
                app.equiped = True
                app.equipItem.equiped = True
                app.itemDragged.equiped = True
                app.itemDragged = None
                app.itemDraggedX = None
                app.itemDraggedY = None

# redrawAll
def drawequiped(app):
    if app.equipItem != None and app.moveEquipToStore == False and app.equiped == True:
        image = openImage(app.toolImage[app.equipItem.name], 2/3, 2/3)
        drawImage(image, 675, app.height-25, align = 'center')
    elif app.equipItem != None and app.moveEquipToStore:
        image = openImage(app.toolImage[app.equipItem.name], 2/3, 2/3)
        drawImage(image, app.equipItem.x, app.equipItem.y, align = 'center')