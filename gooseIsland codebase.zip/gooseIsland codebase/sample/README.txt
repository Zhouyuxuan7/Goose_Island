15-122 Principles of Imperative Computation
Sample

==========================================================

Files you will modify:
   factorial.c0         - computes the factorial function
   favorite_number.c0   - just returns an int

Files you won't modify:

Files that don't exist yet:

==========================================================

Compiling:
   % cc0 -d -W factorial.c0
   % ./a.out

==========================================================

Submitting from the command line on andrew:
   % autolab122 handin sample factorial.c0 favorite_number.c0
then display autolab's feedback by running:
   % autolab122 feedback

Creating a tarball to submit with autolab.andrew.cmu.edu web interface:
   % tar -czvf handin.tgz factorial.c0 favorite_number.c0
