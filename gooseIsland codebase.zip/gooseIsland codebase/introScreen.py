from cmu_graphics import *
from iniscreen import *
from PIL import Image

# This file drew the home screen

def intro_onAppStart(app):
    app.width = 850
    app.height = 550
    app.startSizeBig = False
    app.exitSizeBig = False
    decOpen(app)

def openImage(imagePath, widthRatio = 1, heightRatio = 1):
    image = Image.open(imagePath)
    image = image.resize((math.floor(image.width*widthRatio), math.floor(image.height*heightRatio)))
    return CMUImage(image)

def openFlippedImage(imagePath, widthRatio = 1, heightRatio = 1):
    image = Image.open(imagePath)
    image = image.resize((math.floor(image.width*widthRatio), math.floor(image.height*heightRatio)))
    imageFlipped = image.transpose(Image.FLIP_LEFT_RIGHT)
    return CMUImage(imageFlipped)

# CITATION:
# app.gooseKnife is from https://www.zedge.net/wallpaper/74e2212b-9866-47ed-85cf-f97a5b0ca077
# app.terrorMons is from https://dontstarve.fandom.com/wiki/Shadow_Creature?file=Terrorbeak_large_by_mf99k-d9fr75x.gif#Gallery
# app.swimmingGoose is from https://www.deviantart.com/ellenent/art/Untitled-Goose-Game-814884928
# island is from https://stock.adobe.com/search/images?k=island+cartoon
def decOpen(app):
    app.gooseKnife = openImage('Images/dec/gooseKnife.png', 2/3, 2/3)
    app.terrorMons = openImage('Images/dec/Terrorbeak.png')
    app.swimmingGoose = openFlippedImage('Images/dec/Swimming goose.png', 1/3, 1/3)
    app.islandImage = openImage('Images/dec/Island2.png', 1/2, 1/2)
    app.islandLarge = openImage('Images/dec/Island2.png', 2/3, 2/3)

def intro_onMousePress(app, mouseX, mouseY):
    if 280 <= mouseX <= 450 and 375 <= mouseY <= 460:
        newGame(app)
        setActiveScreen('ini')

def intro_onMouseMove(app, mouseX, mouseY):
    if 280 <= mouseX <= 450 and 375 <= mouseY <= 460:
        app.startSizeBig = True
    else: 
        app.startSizeBig = False
    if 520<= mouseX <= 690 and 375 <= mouseY <= 460:
        app.exitSizeBig = True
    else: 
        app.exitSizeBig = False

def intro_redrawAll(app):
    drawRect(app.width/2, app.height/2, app.width, app.height, align = 'center', fill = 'royalblue')
    drawOval(app.width/2, 200, 600, 250, align = 'center', fill = 'bisque', border = 'saddlebrown', borderWidth = 10)
    
    if app.startSizeBig:
        startSize = 70 
        islandStartImage = app.islandLarge
    else:
        startSize = 50
        islandStartImage = app.islandImage
    drawImage(islandStartImage, 370, 400, align = 'center')
    drawLabel('Start', 370, 425, fill = 'black', size = startSize, bold = True)
    if app.exitSizeBig:
        exitSize = 70
        islandExitImage = app.islandLarge
    else:
        exitSize = 50
        islandExitImage = app.islandImage
    drawImage(islandExitImage, 610, 400, align = 'center')
    drawLabel('Exit', 610, 425, fill = 'black', size = exitSize, bold = True)
    drawLabel('Goose', 340, 145, size = 100, fill = 'black', bold = True)
    drawLabel('Island', 510, 260, size = 100, fill = 'black', bold = True)
    drawImage(app.gooseKnife, 275, 250, align = 'center')
    drawImage(app.terrorMons, 530, 120, align = 'center')
    drawImage(app.swimmingGoose, 150, 425, align = 'center')

    
# runAppWithScreens(initialScreen = 'intro')