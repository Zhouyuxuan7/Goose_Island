from cmu_graphics import *
from introScreen import *
from PIL import Image
import random
import math

# This file drew the happy ending screen. 

def distance(x1, y1, x2, y2):
    return ((x1-x2)**2 + (y1-y2)**2) **0.5

def openImage(imagePath, widthRatio = 1, heightRatio = 1):
    image = Image.open(imagePath)
    image = image.resize((math.floor(image.width*widthRatio), math.floor(image.height*heightRatio)))
    return CMUImage(image)

def end_onAppStart(app):
    reset(app)

def reset(app):
    app.level = 0
    app.width = 850
    app.height = 550
    app.endingWords = False
    app.endNight = False
    app.endDay = True
    app.leafCounter = 0
    leavePos(app)

def leavePos(app):
    app.leavesSet = set()
    # for i in range(10):
    #     leavesX = random.randint(650, 850)
    #     leavesY = random.randint(10, 50)
    #     radius = random.randint(5, 10)
    #     colorSet = ['plum', 'pink']
    #     colorInd = random.randint(0, len(colorSet)-1)
    #     color = colorSet[colorInd]
    #     app.leavesSet.append(leaf(leavesX, leavesY, radius, color))

def drawFractal(level, sX, sY, eX, eY, dis, angle, width, colorSet):
    if level == 0:
        drawLine(sX, sY, eX, eY, lineWidth = width)
    else:
       drawLine(sX, sY, eX, eY, lineWidth = width)
       sX = eX
       sY = eY
       dis *= 2/3
       width *= 2/3
       eX1 = sX - dis*math.sin(angle+math.pi/6)
       eY1 = sY - dis*math.cos(angle+math.pi/6)
       eX2 = sX - dis*math.sin(angle-math.pi/9)
       eY2 = sY - dis*math.cos(angle-math.pi/9)
       if dis <= 30:
           radius = random.randint(5, 10)
        #    colorSet = ['green', 'yellowgreen']
        #    colorSet = ['plum', 'pink']
           colorInd = random.randint(0, len(colorSet)-1)
           drawCircle(eX1, eY1, radius, fill = colorSet[colorInd])
           drawCircle(eX2, eY2, radius, fill = colorSet[colorInd])
       drawFractal(level-1, sX, sY, eX1, eY1, dis, angle+math.pi/6, width, colorSet)
       drawFractal(level-1, sX, sY, eX2, eY2, dis, angle-math.pi/9, width, colorSet)

def end_onKeyPress(app, key):
    if app.level == 8:
        app.endingWords = True
    if key in ['up', 'right'] and (app.level <= 7):
        app.level += 1
    elif (key in ['down', 'left']) and (app.level > 0):
        app.level -= 1
    if key == 'd':
        app.endDay = True
        app.endNight = False
    if key == 'n':
        app.endNight = True
        app.endDay = False

def end_onMousePress(app, mouseX, mouseY):
    if app.endingWords:
        if 125 <= mouseX <= 275 and 225 <= mouseY <= 275:
            setActiveScreen('intro')

def end_onStep(app):
    app.leafCounter += 1
    class leaf:
        def __init__(self, x, y, radius, color):
            self.x = x
            self.y = y
            self.r = radius
            self.color = color
        
        def draw(self):
            drawCircle(self.x, self.y, self.r, fill = self.color)
    if app.leafCounter % 4 == 0:
        leavesX = random.randrange(500, 850, 10)
        leavesY = random.randint(10, 70)
        radius = random.randint(5, 10)
        colorSet = ['plum', 'pink']
        colorInd = random.randint(0, len(colorSet)-1)
        color = colorSet[colorInd]
        app.leavesSet.add(leaf(leavesX, leavesY, radius, color))
    for leaf in app.leavesSet:
        leaf.x -= 2
        leaf.y += 5
    for leaf in app.leavesSet:
        if leaf.y <= 10:
            app.leavesSet.remove(leaf)

def end_redrawAll(app):
    labelNightDay = 'n'
    colorSet = ['green', 'yellowgreen']
    if app.endNight: 
        colorSet = ['plum', 'pink']
        drawRect(0, 0, app.width, 400, fill = 'midnightblue')
        drawRect(0, 400, app.width, 150, fill = 'tan')
        # drawLabel('Press d', app.width/2, app.height - 40, size = 16)
        labelNightDay = 'd'
        # drawLabel("Press d.", 120, app.height-80)
    elif app.endDay: 
        colorSet = ['green', 'yellowgreen']
        drawRect(0, 0, app.width, 400, fill = 'cornflowerblue')
        drawRect(0, 400, app.width, 150, fill = 'bisque')
        # drawLabel('Press n', app.width/2, app.height - 40, size = 16)
        labelNightDay = 'n'
        # drawLabel("Press n.", 120, app.height-80)
    # drawLabel('Press arrows to grow the tree.', app.width/2, app.height - 20, size = 16)
    drawFractal(app.level, 650, app.height - 10, 650, app.height - 160, 200, 0, 15, colorSet)
    if app.endNight and app.level >= 6:
        for leaf in app.leavesSet:
            leaf.draw()
    if app.endingWords:
        # drawLabel("'Do not gentle into that good night.'", 150, 50, size = 16, fill = 'white')
        # drawLabel("---Dylan Thomas", 150, 70, size = 16, fill = 'white')
        fontCol = 'white' if app.endNight else 'black'
        drawLabel('Thanks for playing', 200, 100, size = 40, fill = fontCol, bold = True)
        drawLabel('Goose Island!', 200, 150, size = 40, fill = fontCol, bold = True)
        color = 'tan' if app.endNight else 'bisque'
        drawRect(200, 250, 150, 50, align = 'center', fill = color, border = 'darkgoldenrod', borderWidth = 3)
        drawLabel('Exit to title', 200, 250, align = 'center', fill = fontCol, size = 25)
    
    imageGooseHead = openImage('Images/dec/gooseHead.png', 1/2, 1/2)
    drawImage(imageGooseHead, 70, 494, align = 'center')
    drawOval(120, app.height - 90, 200, 50, align = 'center', fill = 'bisque', border = 'saddlebrown', borderWidth = 3)
    drawLabel("Press arrows to grow the tree.", 120, app.height-100)
    drawLabel(f"Press {labelNightDay}.", 120, app.height-80)

    # drawLabel("Press n.", 120, app.height-80)

# runAppWithScreens(initialScreen = 'end')

