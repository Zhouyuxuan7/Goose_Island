from cmu_graphics import *
from PIL import Image
import os, pathlib
import math

# This file record collected items and craft new items. 

# Classes
class CraftItem:
    def __init__(self, name, object1, object1Num, object2, object2Num, row, col, effect):
        self.name = name
        self.ob1 = object1
        self.num1= object1Num
        self.ob2 = object2
        self.num2 = object2Num
        self.showhint = False
        self.row = row
        self.col = col
        self.effect = effect
        self.createOnMouse = False
        self.equiped = False
        self.x = None
        self.y = None
    
    def __repr__(self):
        return f'CraftItem, {self.name}'
    
    def drawhint(self):
        left, top = getCellLeftTop(app, self.row, self.col)
        drawRect(left+25, top+25, 60, 50, fill = 'white')
        image1 = openImage(app.materialPic[self.ob1], 1/3, 1/3)
        if self.ob2 != None:
            image2 = openImage(app.materialPic[self.ob2], 1/3, 1/3)
            drawImage(image1, left+45, top+35, align = 'center')
            drawImage(image2, left+45, top+50, align = 'center')
            drawLabel(f'x {self.num1}', left+63, top+35)
            drawLabel(f'x {self.num2}', left+63, top+50)
            drawLabel(f'{self.effect}', left+53, top+65, size = 10)
        else:
            drawImage(image1, left+45, top+50)
            drawLabel(f'x{self.num1}', left+63, top+50)

    def drawCreatedItem(self):
        if self.x != None and self.y != None:
            image = openImage(app.toolImage[self.name])
            drawImage(image, self.x, self.y, align = 'center')
    
    def draw(self, x, y):
        image = openImage(app.toolImage[self.name])
        drawImage(image, x, y, align = 'center', width = 45, height = 40)

class Material:
    def __init__(self, name, image):
        self.name = name
        self.image = image
        self.selected = False

    def __repr__(self):
        return f'Material, {self.name}'

    def __hash__(self):
        return hash(str(self))
    
    def __eq__(self, other):
        return (isinstance(other, Material) and self.name == other.name)
    
    def draw(self, x, y):
        self.x = x
        self.y = y
        drawImage(self.image, x, y, align = 'center', width = 45, height = 40)

class Food:
    def __init__(self, name, image):
        self.name = name
        self.image = image

    def __repr__(self):
        return f'Food, {self.name}'

    def __hash__(self):
        return hash(str(self))
    
    def __eq__(self, other):
        return (isinstance(other, Food) and self.name == other.name)
    
    def draw(self, x, y):
        drawImage(self.image, x, y, align = 'center', width = 45, height = 40)

# CITATION: loadSound function code is from CMU 15112 sound demo
def loadSound(relativePath): 
    absolutePath = os.path.abspath(relativePath)
    url = pathlib.Path(absolutePath).as_uri()
    return Sound(url)

# onAppStart
# CITATION: app.craftSound is from https://pixabay.com/sound-effects/search/collect/
def collect(app):
    app.collectedItems = dict()
    # Use to check the HE: {app.craftCondition['machine']: 1, app.craftCondition['bookcase']: 1}
    app.toolBar = False
    app.craft = False
    app.mapShow = False
    app.craftSound = loadSound('Sound/item-craft.mp3')
    toolBoard(app)

def toolBoard(app):
    app.rows = 6
    app.cols = 10
    app.boardLeft = app.width/2-250
    app.boardTop = app.height/2 -150
    app.boardWidth = 500
    app.boardHeight = 300
    app.cellBorderWidth = 2

# Citation: I got the images from https://dontstarve.fandom.com/wiki/Don%27t_Starve_Wiki
## Lists of icons and craft conditions
app.foodPic = {'berries': 'Images/Food/Berries.webp', 
               'rawCarrot': 'Images/Food/Raw_Carrot.webp',
               'seaweed': 'Images/Food/Seaweed.webp'}
app.foodValue = {'berries': 10, 'rawCarrot': 5}

app.materialPic = {'twigs':'Images/Materials/Twigs.webp', 
                   'flint': 'Images/Materials/Flint.webp',
                   'cut grass': 'Images/Materials/Cut_Grass.webp',
                   'rock': 'Images/Materials/Rocks.webp',
                   'gold': 'Images/Materials/Gold_Nugget.webp',
                   'grass tuft': 'Images/Materials/Grass_Tuft_Item.webp',
                   'iron': 'Images/Materials/Iron_Ore.webp',
                   'coral':'Images/Materials/Coral.webp',
                   'ice': 'Images/Materials/Ice.webp',
                   'nitre': 'Images/Materials/Nitre.webp',
                   'alloy': 'Images/Materials/Alloy.webp',
                   'axe': 'Images/Craft Items/Tools/Axe.webp',
                   'pickaxe': 'Images/Craft Items/Tools/Pickaxe.webp',
                   'wool': 'Images/Craft Items/Tools/Beefalo_Wool.webp',
                   'rope': 'Images/Craft Items/Tools/Rope.webp',
                   'cutstone': 'Images/Craft Items/Tools/Cut_Stone.webp',
                   'hammer': 'Images/Craft Items/Tools/Hammer.webp',
                   'gun': 'Images/Craft Items/Tools/Spear_Gun.webp',
                   'board': 'Images/Craft Items/Tools/Boards.webp',
                   'machine': 'Images/Craft Items/Tools/Science_Machine.webp',
                   'bookcase': 'Images/Craft Items/Tools/Bookcase.webp'}

app.toolImage = {'axe': 'Images/Craft Items/Tools/Axe.webp', 
                 'pickaxe': 'Images/Craft Items/Tools/Pickaxe.webp',
                 'wool': 'Images/Craft Items/Tools/Beefalo_Wool.webp',
                 'rope': 'Images/Craft Items/Tools/Rope.webp',
                 'cutstone': 'Images/Craft Items/Tools/Cut_Stone.webp',
                 'hammer': 'Images/Craft Items/Tools/Hammer.webp',
                 'gun': 'Images/Craft Items/Tools/Spear_Gun.webp',
                 'board': 'Images/Craft Items/Tools/Boards.webp',
                 'machine': 'Images/Craft Items/Tools/Science_Machine.webp',
                 'bookcase': 'Images/Craft Items/Tools/Bookcase.webp',
                 'key': 'Images/Craft Items/Tools/Key_to_the_City.webp'}

app.craftCondition = {'axe': CraftItem('axe', 'twigs', 1, 'flint', 1, 0, 0, 
                                       'Attack +15'),
                    'pickaxe': CraftItem('pickaxe', 'twigs', 2, 'rock', 2, 0, 1, 
                                         'Attack +5'),
                    'wool': CraftItem('wool', 'cut grass', 3, 'coral', 3, 0, 2, 
                                      'Wearing'),
                    'rope': CraftItem('rope', 'cut grass', 3, 'grass tuft', 3, 0, 3, 
                                      'Tie'),
                    'cutstone': CraftItem('cutstone', 'pickaxe', 1, 'wool', 1, 0, 4, 
                                          'Building'),
                    'hammer': CraftItem('hammer', 'axe', 1, 'rope', 2, 0, 5, 
                                        'Building'),
                    'gun': CraftItem('gun', 'iron', 5, 'ice', 3, 0, 6, 
                                     'Attack + 20'),
                    'board': CraftItem('board', 'gold', 7, 'axe', 1, 0, 7, 
                                     'Building'),
                    'machine': CraftItem('machine', 'cutstone', 1, 'hammer', 1, 0, 8, 
                                         'Technology'),
                    'bookcase': CraftItem('bookcase', 'gun', 1, 'board', 2, 0, 9,
                                          'Knowledge'),
                    'key': CraftItem('key', 'machine', 1, 'bookcase', 1, 1, 0,
                                     'Key to heaven')}

## onMouseMove
def craftHint(app, mouseX, mouseY):
    for tool in app.craftCondition:
        app.craftCondition[tool].showhint = False
        row = app.craftCondition[tool].row
        col = app.craftCondition[tool].col
        left, top = getCellLeftTop(app, row, col)
        if left <= mouseX <= left+50 and top <= mouseY <= top + 50:
            app.craftCondition[tool].showhint = True

def createdItemOnMouse(app, mouseX, mouseY):
    for tool in app.craftCondition:
        craftedItem = app.craftCondition[tool]
        if craftedItem.createOnMouse:
            craftedItem.x = mouseX
            craftedItem.y = mouseY

## onMousePress
def crafting(app, mouseX, mouseY):
    if 0 <= mouseX <= 50 and 75 <= mouseY <= 125:
        app.pause = not app.pause
        app.craft = not app.craft
        app.toolBar = not app.toolBar
    if app.toolBar:
        if 175 <= mouseX <= 225 and 75 <= mouseY <= 125:
            app.mapShow = False
            if app.craft == False: app.craft = True
        if 225 <= mouseX <= 275 and 75 <= mouseY <= 125:
            app.craft = False
            if app.mapShow == False: app.mapShow = True
    if app.craft:
        for tool in app.craftCondition:
            craftItem = app.craftCondition[tool]
            row = craftItem.row
            col = craftItem.col
            left, top = getCellLeftTop(app, row, col)
            if craftItem.ob1 in app.toolImage: 
                material1= app.craftCondition[craftItem.ob1]
            else: 
                material1 = Material(craftItem.ob1, openImage(app.materialPic[craftItem.ob1]))
            if craftItem.ob2 in app.toolImage: 
                material2= app.craftCondition[craftItem.ob2]
            else: 
                material2 = Material(craftItem.ob2, openImage(app.materialPic[craftItem.ob2]))
            if (left <= mouseX <= left+50 and top <= mouseY <= top + 50 
                and material1 in app.collectedItems 
                and material2 in app.collectedItems ):
                if (app.collectedItems[material1] >= craftItem.num1 
                    and app.collectedItems[material2] >= craftItem.num2):
                    craftItem.createOnMouse = True
                    app.craftSound.play(restart = True)
                    app.collectedItems[material1] -= craftItem.num1
                    app.collectedItems[material2] -= craftItem.num2
                    if app.collectedItems[material1] == 0: 
                        app.collectedItems.pop(material1)
                    if app.collectedItems[material2] == 0: 
                        app.collectedItems.pop(material2)
                    # If created the key: unlock happy ending
                    if craftItem.name == 'key':
                        app.happyEnding = True
                        app.noteShown = True

def puttingCraftedItem(app, mouseX, mouseY): 
    for tool in app.craftCondition:
        craftItem = app.craftCondition[tool]
        if (150 <= mouseX <= 650 and app.height-50 <= mouseY <= app.height 
            and craftItem.createOnMouse == True):
            if craftItem not in app.collectedItems and len(app.collectedItems) < 10:
                app.collectedItems[craftItem] = 1
            elif craftItem in app.collectedItems: 
                app.collectedItems[craftItem] += 1
            craftItem.createOnMouse = False
        elif (650 <= mouseX <= 700 and app.height-50 <= mouseY <= app.height 
              and app.equiped == False and craftItem.createOnMouse == True):
            app.equipItem = craftItem
            app.equiped = True
            craftItem.equiped = True
            craftItem.createOnMouse = False
        # elif (650 <= mouseX <= 700 and app.height-50 <= mouseY <= app.height 
        #       and app.equiped == True and app.equipItem == craftItem):
        #     app.moveEquipToStore = True

## Draw Craft tab
def drawCrafting(app):
    iconImage = openImage('Images/Craft Items/Icon_Tools.png', 1/2, 1/2)
    drawRect(25, 100, 50, 50, align = 'center', fill = 'tan', border = 'darkgoldenrod', borderWidth = 3)
    drawImage(iconImage, 25, 100, align = 'center')
    if app.toolBar == True:
        drawRect(app.width/2, app.height/2, 500, 300, align = 'center', fill = 'tan', border = 'darkgoldenrod', borderWidth = 5)
        if app.craft:
            mapButtonCol = 'tan'
            craftButtonCol = 'lightblue'   
            drawToolBoard(app)
            drawTool(app)
            drawCreatedTool(app)
        if app.mapShow:
            mapButtonCol = 'lightblue'
            craftButtonCol = 'tan'
            mapImage = openImage('Images/Background/map.png', 1/3, 1/3)
            positionImage = openImage('Images/Background/MapImage.png', 1/7, 1/7)
            drawRect(app.width/2, app.height/2, 460, 260, align = 'center', fill = 'dodgerblue')
            drawImage(mapImage, app.width/2, app.height/2, align = 'center')
            positionX = 292 + 266/14 + 266/7 * (app.col)
            positionY = 160 + 230/12 + 230/6 * (app.row)
            drawImage(positionImage, positionX, positionY, align = 'center')
        drawRect(175, 75, 50, 50, fill = craftButtonCol, border = 'darkgoldenrod', borderWidth = 3)
        drawRect(225, 75, 50, 50, fill = mapButtonCol, border = 'darkgoldenrod', borderWidth = 3)
        mapIconImage = openImage('Images/Background/Map_Scroll.webp', 2/3, 2/3)
        drawImage(mapIconImage, 250, 100, align = 'center')
        toolIconImage = openImage('Images/Background/ToolButton.webp', 2/3, 2/3)
        drawImage(toolIconImage, 200, 100, align = 'center')

def drawToolBoard(app):
    drawBoard(app)
    drawBoardBorder(app)

def drawTool(app):
    row = 0
    col = 0
    for tool in app.toolImage:
        # if tool == 'bookcase': toolImage = openImage(app.toolImage[tool], 1/11, 1/11)
        toolImage = openImage(app.toolImage[tool], 2/3, 2/3)
        left, top = getCellLeftTop(app, row, col)
        drawImage(toolImage, left+25, top+25, align = 'center')
        if col < 9:
            col += 1
        elif col == 9:
            col = 0
            row += 1
    drawHint(app)

def drawHint(app):
    row = 0
    col = 0
    for tool in app.toolImage:
        if app.craftCondition[tool].showhint: 
            app.craftCondition[tool].drawhint()
        if col < 10:
            col += 1
        elif col == 10:
            col = 0
            row += 1

def drawCreatedTool(app):
    for tool in app.craftCondition:
        craftItem = app.craftCondition[tool]
        if craftItem.createOnMouse == True:
            craftItem.drawCreatedItem()

def drawBoard(app):
    for row in range(app.rows):
        for col in range(app.cols):
            drawCell(app, row, col)

def drawBoardBorder(app):
  # draw the board outline (with double-thickness):
  drawRect(app.boardLeft, app.boardTop, app.boardWidth, app.boardHeight,
           fill=None, border='darkgoldenrod',
           borderWidth=2*app.cellBorderWidth)

def drawCell(app, row, col):
    cellLeft, cellTop = getCellLeftTop(app, row, col)
    cellWidth, cellHeight = getCellSize(app)
    drawRect(cellLeft, cellTop, cellWidth, cellHeight,
             fill=None, border='darkgoldenrod',
             borderWidth=app.cellBorderWidth)

def getCellLeftTop(app, row, col):
    cellWidth, cellHeight = getCellSize(app)
    cellLeft = app.boardLeft + col * cellWidth
    cellTop = app.boardTop + row * cellHeight
    return (cellLeft, cellTop)

def getCellSize(app):
    cellWidth = app.boardWidth / app.cols
    cellHeight = app.boardHeight / app.rows
    return (cellWidth, cellHeight)

# Basic functions
def distance(x1, y1, x2, y2):
    return ((x1-x2)**2 + (y1-y2)**2)**0.5

def openImage(imagePath, widthRatio = 1, heightRatio = 1):
    image = Image.open(imagePath)
    image = image.resize((math.floor(image.width*widthRatio), math.floor(image.height*heightRatio)))
    return CMUImage(image)

def distance(x1, y1, x2, y2):
    return ((x1-x2)**2 + (y1-y2)**2)**0.5


