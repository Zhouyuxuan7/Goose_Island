from cmu_graphics import *
from PIL import Image
from introScreen import *
from iniscreen import *
from EndingScreen import *

# The main file, run the whole game

def onAppStart(app):
    app.width = 850
    app.height = 550

def intro_onKeyPress(app, key):
    if key == '5':
        setActiveScreen('end')

runAppWithScreens(initialScreen = 'intro')
