# This file runs the game screen

from cmu_graphics import *
from PIL import Image
from resource1 import *
from gooseMove import *
from background import *
from collectCrafting import * 
from indicators import *
from equipedItem import *
from monster import *
from EndingScreen import *
from introScreen import *
import random

def ini_onAppStart(app):
    newGame(app)

def newGame(app):
    app.width = 850
    app.height = 550
    app.stepsPerSecond = 10
    app.pause = False
    background(app)
    goose(app)
    configure(app)
    collect(app)
    indicators(app)
    equiped(app)
    monsterInd(app)
    gooseNightPos(app)

def ini_onStep(app):
    if not app.pause: 
        clockWalk(app)
        gooseWalk(app)
        backGroundSwitch(app)
        monsterAppear(app)
    if app.pause == False and app.night == True:
        gooseMoveNight(app)

def ini_onKeyPress(app, key):
    ## short cut for game
    if key == '1': # Skip to the night
        monsterInd(app)
        app.stepCounter = 1800
    if key == '2': # Final crafting
        app.collectedItems = {app.craftCondition['machine']: 1, app.craftCondition['bookcase']: 1}
    if key == '3': # Little health points
        app.goose.healthPoint = 3
    if key == '4': # Little hunger points
        app.goose.hungerPoint = 3
    # check those instructions
    if key == '6':
        app.stepCounter = 0
    if key == '7':
        app.stepCounter = 100
    if key == '8':
        app.stepCounter = 200
    if key == '9':
        app.stepCounter = 300
    if key == '0':
        app.stepCounter = 400
    attack(app, key)
    # if app.night: gooseNightMove(app, key)

def ini_onKeyHold(app, keys):
    if not app.pause:
        gooseMovement(app, keys)

def ini_onKeyRelease(app, key):
    if not app.pause:
        gooseStop(app, key)

def ini_onMouseDrag(app, mouseX, mouseY):
    moveCurrentItem(app, mouseX, mouseY)

# def ini_onMouseRelease(app, mouseX, mouseY):
#     moveCurrentItemToDes(app, mouseX, mouseY)

def ini_onMouseMove(app, mouseX, mouseY):
    craftHint(app, mouseX, mouseY)
    createdItemOnMouse(app, mouseX, mouseY)
    moveEquipToStore(app, mouseX, mouseY)

def ini_onMousePress(app, mouseX, mouseY):
    happyEnding(app, mouseX, mouseY)
    if not app.pause: 
        forestCollect(app, mouseX, mouseY)
    itemIsDragged(app, mouseX, mouseY)
    crafting(app, mouseX, mouseY)
    pressEquipToStore(app, mouseX, mouseY)
    puttingCraftedItem(app, mouseX, mouseY)
    if app.finalHouseDrew and 480 <= mouseX <= 660 and 300 <= mouseY <= 445 and distance(app.goose.x, app.goose.y, 570, 372) <= 100:
        reset(app)
        setActiveScreen('end')
    if app.goose.hungerPoint <= 0 or app.goose.healthPoint <= 0:
        if 250 <= mouseX <= 400 and 290 <= mouseY <= 330:
            newGame(app)
        elif 450 <= mouseX <= 600 and 290 <= mouseY <= 330:
            setActiveScreen('intro')

def ini_onMouseRelease(app, mouseX, mouseY):
    moveCurrentItemToDes(app, mouseX, mouseY)

def ini_redrawAll(app):
    drawBackground(app)

    # Happy Ending House:
    if app.finalHouseDrew:
        house = openImage('Images/Happy Ending/Farm_House.webp', 1, 1)
        drawImage(house, app.width*2/3, app.height/2, align = 'center')

    # Make sure resources with larger y values are drawn after goose
    drawResBeforeGoose(app)
    drawGoose(app)
    drawResAfterGoose(app)
    if app.night: drawMonster(app)

    # Bag
    for i in range(10):
        drawRect(150+i*50, app.height-50, 50, 50, fill = 'dimgrey', border = 'black', borderWidth = 3)
    drawRect(650, app.height-50, 50, 50, fill = 'darkslategrey', border = 'black', borderWidth = 5)
    
    # Draw materials in bag
    matCount = 0
    # print(app.collectedItems)
    for item in app.collectedItems:
        item.draw(175+matCount*50, app.height-30)
        drawLabel(f'{app.collectedItems[item]}', 175+matCount*50, app.height-10)
        matCount += 1

    drawCrafting(app)
    drawequiped(app)
    drawIndicators(app)
    
    # Move items
    if isinstance(app.itemDragged, CraftItem) and app.itemDragged.equiped:
        pass
    elif (app.itemIsDragged and app.itemDraggedX != None and app.itemDraggedY != None 
        and app.itemDragged != None):
        app.itemDragged.draw(app.itemDraggedX, app.itemDraggedY)
    # drawDayTrans(app)

# runAppWithScreens(initialScreen= 'ini')